package com.mashibing.lambda.demo1;

public interface Factory {

    Object getObject();

}
