package com.mashibing.lambda.demo2;

public interface IGreeting {

    void sayHello(String message);
}
