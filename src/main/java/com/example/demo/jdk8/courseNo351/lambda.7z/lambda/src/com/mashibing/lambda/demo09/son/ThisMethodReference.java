package com.mashibing.lambda.demo09.son;

public class ThisMethodReference {
    public static void main(String[] args) {
        new Husband().soHappy();
    }
}
